package com.lameguard.crypt;

import com.lameguard.utils.Rnd;

public class BlowFishKeygen {
    public static byte[] getRandomKey() {
        return Rnd.nextBytes(new byte[64]);
    }
}
