package com.lameguard.crypt;

public class LameKey {
}
