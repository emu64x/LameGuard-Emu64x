package com.lameguard.crypt;

public class LamePacket {
}
