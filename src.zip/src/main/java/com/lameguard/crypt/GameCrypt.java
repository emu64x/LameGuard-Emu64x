package com.lameguard.crypt;

import com.lameguard.crypt.impl.L2C;
import com.lameguard.crypt.impl.L2S;

public class GameCrypt {
    private LameCrypt f0c;
    private boolean isEnabled = false;
    private boolean isProtected = true;
    private LameCrypt f1s;

    public void setProtected(boolean state) {
        this.isProtected = state;
    }

    public void setKey(byte[] key) {
        this.f0c = new L2C();
        this.f0c.setup(key, null);
        this.f1s = new L2S();
        this.f1s.setup(key, null);
    }

    public void decrypt(byte[] raw, int offset, int size) {
        if (this.isEnabled) {
            this.f0c.crypt(raw, offset, size);
        }
    }

    public void encrypt(byte[] raw, int offset, int size) {
        if (this.isEnabled) {
            this.f1s.crypt(raw, offset, size);
        } else {
            this.isEnabled = true;
        }
    }
}
