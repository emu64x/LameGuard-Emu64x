package com.lameguard.crypt;

public interface LameCrypt {
    void crypt(byte[] bArr, int i, int i2);

    void setup(byte[] bArr, byte[] bArr2);
}
