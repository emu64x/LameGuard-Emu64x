package com.lameguard.crypt.impl;

import com.lameguard.crypt.LameCrypt;

public class L2S implements LameCrypt {
    private byte[] key = new byte[16];

    public void setup(byte[] key, byte[] iv) {
        System.arraycopy(key, 0, this.key, 0, 16);
    }

    public void crypt(byte[] raw, int offset, int size) {
        int temp = 0;
        for (int i = 0; i < size; i++) {
            temp ^= this.key[i & 15] ^ (raw[offset + i] & 255);
            raw[offset + i] = (byte) temp;
        }
        int old = ((((this.key[8] & 255) | ((this.key[9] << 8) & 65280)) | ((this.key[10] << 16) & 16711680)) | ((this.key[11] << 24) & -16777216)) + size;
        this.key[8] = (byte) (old & 255);
        this.key[9] = (byte) ((old >> 8) & 255);
        this.key[10] = (byte) ((old >> 16) & 255);
        this.key[11] = (byte) ((old >> 24) & 255);
    }
}
