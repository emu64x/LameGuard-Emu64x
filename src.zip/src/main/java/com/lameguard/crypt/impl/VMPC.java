package com.lameguard.crypt.impl;

import com.lameguard.crypt.LameCrypt;

public class VMPC implements LameCrypt {
    private byte[] f2P = new byte[256];
    private byte f3n = (byte) 0;
    private byte f4s = (byte) 0;

    public void setup(byte[] key, byte[] iv) {
        int m;
        this.f4s = (byte) 0;
        for (int i = 0; i < 256; i++) {
            this.f2P[i] = (byte) (i & 255);
        }
        for (m = 0; m < 768; m++) {
            this.f4s = this.f2P[((this.f4s + this.f2P[m & 255]) + key[m % 64]) & 255];
            byte temp = this.f2P[m & 255];
            this.f2P[m & 255] = this.f2P[this.f4s & 255];
            this.f2P[this.f4s & 255] = temp;
        }
        for (m = 0; m < 768; m++) {
            this.f4s = this.f2P[((this.f4s + this.f2P[m & 255]) + iv[m % 64]) & 255];
            temp = this.f2P[m & 255];
            this.f2P[m & 255] = this.f2P[this.f4s & 255];
            this.f2P[this.f4s & 255] = temp;
        }
        for (m = 0; m < 768; m++) {
            this.f4s = this.f2P[((this.f4s + this.f2P[m & 255]) + key[m % 64]) & 255];
            temp = this.f2P[m & 255];
            this.f2P[m & 255] = this.f2P[this.f4s & 255];
            this.f2P[this.f4s & 255] = temp;
        }
        this.f3n = (byte) 0;
    }

    public void crypt(byte[] raw, int offset, int size) {
        for (int i = 0; i < size; i++) {
            this.f4s = this.f2P[(this.f4s + this.f2P[this.f3n & 255]) & 255];
            byte z = this.f2P[(this.f2P[this.f2P[this.f4s & 255] & 255] + 1) & 255];
            byte temp = this.f2P[this.f3n & 255];
            this.f2P[this.f3n & 255] = this.f2P[this.f4s & 255];
            this.f2P[this.f4s & 255] = temp;
            this.f3n = (byte) ((this.f3n + 1) & 255);
            raw[offset + i] = (byte) (raw[offset + i] ^ z);
        }
    }
}
