package com.lameguard.session;

import java.util.Arrays;

public class IpSession {
    private final String ip;
    private long[] uniques = new long[0];

    public IpSession(String ip) {
        this.ip = ip;
    }

    public void setData(int token, int checksum) {
        long l = ((((long) token) & 4294967295L) << 32) + ((long) checksum);
        synchronized (this) {
            this.uniques = Arrays.copyOf(this.uniques, this.uniques.length + 1);
            this.uniques[this.uniques.length - 1] = l;
        }
    }

    public boolean isUnique(int token, int checksum) {
        long l = ((((long) token) & 4294967295L) << 32) + ((long) checksum);
        synchronized (this) {
            for (long uniq : this.uniques) {
                if (uniq == l) {
                    return false;
                }
            }
            return true;
        }
    }

    public String getIP() {
        return this.ip;
    }

    public String toString() {
        return "[ip: " + this.ip + "]";
    }
}
