package com.lameguard.session;

import java.io.Serializable;

public class ClientSession implements Serializable {
    private static final long serialVersionUID = 3235066710117934181L;
    private final String account;
    private final String hwid;
    private final int instances;
    private final String ip;
    private final int patch;
    private final int token;
    private final int version;

    public ClientSession(String ip, String hwid, String account, int instances, int token, int version, int patch) {
        this.ip = ip;
        this.hwid = hwid;
        this.account = account;
        this.instances = instances;
        this.token = token;
        this.version = version;
        this.patch = patch;
    }

    public String getIP() {
        return this.ip;
    }

    public String getHWID() {
        return this.hwid;
    }

    public String getAccount() {
        return this.account;
    }

    public int getInstances() {
        return this.instances;
    }

    public int getToken() {
        return this.token;
    }

    public int getVersion() {
        return this.version;
    }

    public int getPatch() {
        return this.patch;
    }

    public final String toString() {
        return "[login : " + this.account + ", ip : " + this.ip + ", hwid : " + this.hwid + "]";
    }
}
