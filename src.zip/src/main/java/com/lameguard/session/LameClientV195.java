package com.lameguard.session;

public interface LameClientV195 {
    String getHWID();

    int getInstanceCount();

    int getPatchVersion();

    boolean isProtected();

    void setHWID(String str);

    void setInstanceCount(int i);

    void setPatchVersion(int i);

    void setProtected(boolean z);
}
