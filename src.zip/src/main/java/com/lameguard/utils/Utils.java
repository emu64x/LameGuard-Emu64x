package com.lameguard.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {
    public static final int BYTES_PER_INT = 4;
    public static final int BYTES_PER_LONG = 8;
    public static final String DATE_FORMAT = "yy.MM.dd HH:mm:ss";
    private static final Pattern HWID_PATTERN = Pattern.compile("([A-Fa-f0-9]{32})");
    private static final Pattern IP_PATTERN = Pattern.compile("([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})");

    public static String findIP(String text) {
        Matcher m = IP_PATTERN.matcher(text);
        if (m.find()) {
            return m.group(1);
        }
        return null;
    }

    public static String findHWID(String text) {
        Matcher m = HWID_PATTERN.matcher(text);
        if (m.find()) {
            return m.group(1);
        }
        return null;
    }

    public static byte[] intToBytes(int value) {
        return intToBytes(new byte[4], 0, value);
    }

    public static byte[] intToBytes(byte[] data, int offset, int value) {
        int i = offset + 1;
        data[offset] = (byte) (value >>> 24);
        offset = i + 1;
        data[i] = (byte) (value >>> 16);
        i = offset + 1;
        data[offset] = (byte) (value >>> 8);
        offset = i + 1;
        data[i] = (byte) (value >>> 0);
        return data;
    }

    public static int bytesToInt(byte[] data, int offset) {
        int offset2 = offset + 1;
        offset = offset2 + 1;
        offset2 = offset + 1;
        offset = offset2 + 1;
        return ((((data[offset] & 255) << 24) | ((data[offset2] & 255) << 16)) | ((data[offset] & 255) << 8)) | ((data[offset2] & 255) << 0);
    }

    public static byte[] longToBytes(long value) {
        return longToBytes(new byte[8], 0, value);
    }

    public static byte[] longToBytes(byte[] data, int offset, long value) {
        intToBytes(data, offset + 0, (int) (value >>> 32));
        intToBytes(data, offset + 4, (int) (value >>> null));
        return data;
    }

    public static long bytesToLong(byte[] data, int offset) {
        return ((((long) bytesToInt(data, offset + 0)) & 4294967295L) << 32) | ((((long) bytesToInt(data, offset + 4)) & 4294967295L) << null);
    }

    public static int bytesToChar(byte[] data, int offset) {
        int offset2 = offset + 1;
        offset = offset2 + 1;
        return ((data[offset] & 255) << 8) | ((data[offset2] & 255) << 0);
    }

    public static byte[] asByteArray(String hex) {
        byte[] buf = new byte[(hex.length() / 2)];
        for (int i = 0; i < hex.length(); i += 2) {
            buf[i / 2] = (byte) (Integer.parseInt(hex.substring(i, i + 2), 16) & 255);
        }
        return buf;
    }

    public static final String asHex(byte[] raw, int offset, int size) {
        StringBuffer strbuf = new StringBuffer(raw.length * 2);
        for (int i = 0; i < size; i++) {
            if ((raw[offset + i] & 255) < 16) {
                strbuf.append("0");
            }
            strbuf.append(Long.toString((long) (raw[offset + i] & 255), 16));
        }
        return strbuf.toString();
    }

    public static final String asHex(byte[] raw) {
        return asHex(raw, 0, raw.length);
    }
}
