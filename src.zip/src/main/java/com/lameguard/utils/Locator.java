package com.lameguard.utils;

import java.io.File;
import java.io.FilenameFilter;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.CharacterIterator;
import java.text.StringCharacterIterator;
import java.util.Locale;

public final class Locator {
    private Locator() {
    }

    public static File getClassSource(Class<?> c) {
        return getResourceSource(c.getClassLoader(), c.getName().replace('.', '/') + ".class");
    }

    public static File getResourceSource(ClassLoader c, String resource) {
        URL url;
        if (c == null) {
            c = Locator.class.getClassLoader();
        }
        if (c == null) {
            url = ClassLoader.getSystemResource(resource);
        } else {
            url = c.getResource(resource);
        }
        if (url != null) {
            String u = url.toString();
            if (u.startsWith("jar:file:")) {
                return new File(fromURI(u.substring(4, u.indexOf("!"))));
            }
            if (u.startsWith("file:")) {
                return new File(fromURI(u.substring(0, u.indexOf(resource))));
            }
        }
        return null;
    }

    public static String fromURI(String uri) {
        URL url = null;
        try {
            url = new URL(uri);
        } catch (MalformedURLException e) {
        }
        if (url == null || !"file".equals(url.getProtocol())) {
            throw new IllegalArgumentException("Can only handle valid file: URIs");
        }
        StringBuffer buf = new StringBuffer(url.getHost());
        if (buf.length() > 0) {
            buf.insert(0, File.separatorChar).insert(0, File.separatorChar);
        }
        String file = url.getFile();
        int queryPos = file.indexOf(63);
        if (queryPos >= 0) {
            file = file.substring(0, queryPos);
        }
        buf.append(file);
        uri = buf.toString().replace('/', File.separatorChar);
        if (File.pathSeparatorChar == ';' && uri.startsWith("\\") && uri.length() > 2 && Character.isLetter(uri.charAt(1)) && uri.lastIndexOf(58) > -1) {
            uri = uri.substring(1);
        }
        return decodeUri(uri);
    }

    private static String decodeUri(String uri) {
        if (uri.indexOf(37) == -1) {
            return uri;
        }
        StringBuffer sb = new StringBuffer();
        CharacterIterator iter = new StringCharacterIterator(uri);
        for (char c = iter.first(); c != '￿'; c = iter.next()) {
            if (c == '%') {
                char c1 = iter.next();
                if (c1 != '￿') {
                    int i1 = Character.digit(c1, 16);
                    char c2 = iter.next();
                    if (c2 != '￿') {
                        sb.append((char) ((i1 << 4) + Character.digit(c2, 16)));
                    }
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static File getToolsJar() {
        boolean toolsJarAvailable = false;
        try {
            Class.forName("com.sun.tools.javac.Main");
            toolsJarAvailable = true;
        } catch (Exception e) {
            try {
                Class.forName("sun.tools.javac.Main");
                toolsJarAvailable = true;
            } catch (Exception e2) {
            }
        }
        if (toolsJarAvailable) {
            return null;
        }
        String javaHome = System.getProperty("java.home");
        if (javaHome.toLowerCase(Locale.US).endsWith("jre")) {
            javaHome = javaHome.substring(0, javaHome.length() - 4);
        }
        File toolsJar = new File(javaHome + "/lib/tools.jar");
        if (toolsJar.exists()) {
            return toolsJar;
        }
        System.out.println("Unable to locate tools.jar. Expected to find it in " + toolsJar.getPath());
        return null;
    }

    public static URL[] getLocationURLs(File location) throws MalformedURLException {
        return getLocationURLs(location, new String[]{".jar"});
    }

    public static URL[] getLocationURLs(File location, final String[] extensions) throws MalformedURLException {
        URL[] urls = new URL[0];
        if (!location.exists()) {
            return urls;
        }
        int i;
        if (location.isDirectory()) {
            File[] matches = location.listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    for (String endsWith : extensions) {
                        if (name.toLowerCase().endsWith(endsWith)) {
                            return true;
                        }
                    }
                    return false;
                }
            });
            urls = new URL[matches.length];
            for (i = 0; i < matches.length; i++) {
                urls[i] = matches[i].toURI().toURL();
            }
            return urls;
        }
        urls = new URL[1];
        String path = location.getPath();
        for (String endsWith : extensions) {
            if (path.toLowerCase().endsWith(endsWith)) {
                urls[0] = location.toURI().toURL();
                break;
            }
        }
        return urls;
    }
}
