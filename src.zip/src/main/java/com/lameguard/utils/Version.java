package com.lameguard.utils;

public class Version {
}
